



$(function() {

	// User Register validation

	var $userRegister = $("#userRegister");

	$userRegister.validate({

		rules: {
			name: {
				required: true,
				lettersonly: true
			}
			,
			email: {
				required: true,
				space: true,
				email: true
			},
			mobile: {
				required: true,
				space: true,
				numericOnly: true,
				minlength: 10,
				maxlength: 12

			},
			password: {
				required: true,
				space: true

			},
			confirmpassword: {
				required: true,
				space: true,
				equalTo: '#pass'

			},
			address: {
				required: true,
				

			},

			city: {
				required: true,
				space: true

			},
			state: {
				required: true,


			},
			pincode: {
				required: true,
				space: true,
				numericOnly: true

			}, img: {
				required: true,
			}

		},
		messages: {
			name: {
				required: 'name is required.',
				lettersonly: 'invalid name.'
			},
			email: {
				required: 'email is required.',
				space: 'space not allowed.',
				email: 'Invalid email.'
			},
			mobile: {
				required: 'mobile number is required.',
				space: 'space not allowed',
				numericOnly: 'invalid mobile no.',
				minlength: 'min 10 digit',
				maxlength: 'max 12 digit'
			}
			,

			city: {
				required: 'city is required',
				space: 'space not allowed'

			},
			state: {
				required: 'state is required',
				space: 'space not allowed'

			},
			pincode: {
				required: 'pincode is required',
				space: 'space are not allowed',
				numericOnly: 'invalid pincode'

			},
			img: {
				required: 'image required',
			},

			password: {
				required: 'password is required',
				space: 'space not allowed'

			}
			,
			address: {
				required: 'address is required',
				

			},
			confirmpassword: {
				required: 'confirm password is required',
				space: 'space not allowed',
				equalTo: 'password mismatch.'

			}
		}
	})


	// Orders Validation

	var $orders = $("#orders");

	$orders.validate({
		rules: {
			firstName: {
				required: true,
				lettersonly: true
			},
			lastName: {
				required: true,
				lettersonly: true
			}
			,
			email: {
				required: true,
				space: true,
				email: true
			},
			mobile: {
				required: true,
				space: true,
				numericOnly: true,
				minlength: 10,
				maxlength: 12

			},
			address: {
				required: true,
				

			},

			city: {
				required: true,
				space: true

			},
			state: {
				required: true,


			},
			pincode: {
				required: true,
				space: true,
				numericOnly: true

			},
			paymentType: {
				required: true
				
			}
		},
		messages: {
			firstName: {
				required: 'first name is required',
				lettersonly: 'invalid name'
			},
			lastName: {
				required: 'last name is required',
				lettersonly: 'invalid name'
			},
			email: {
				required: 'email is required',
				space: 'space not allowed',
				email: 'Invalid email'
			},
			mobile: {
				required: 'mobile number is required',
				space: 'space are not allowed',
				numericOnly: 'invalid mobile no',
				minlength: 'min 10 digit',
				maxlength: 'max 12 digit'
			}
			,
			address: {
				required: 'address is required',
				

			},

			city: {
				required: 'city is required',
				space: 'space not allowed'

			},
			state: {
				required: 'state is required',
				space: 'space not allowed'

			},
			pincode: {
				required: 'pincode is required',
				space: 'space not allowed',
				numericOnly: 'invalid pincode'

			},
			paymentType: {
				required: 'select payment type',
				
			}
		}
	})

	// Reset Password Validation

	var $resetPassword = $("#resetPassword");

	$resetPassword.validate({

		rules: {
			password: {
				required: true,
				space: true

			},
			cPassword: {
				required: true,
				space: true,
				equalTo: '#pass'

			}
		},
		messages: {
			password: {
				required: 'password is required',
				space: 'space are not allowed'

			},
			cpassword: {
				required: 'confirm password is required',
				space: 'space are not allowed',
				equalTo: 'password mismatch'

			}
		}
	})

     //Change password
	var $changePassword = $("#changePassword");

	$changePassword.validate({

		rules: {
			currentPassword: {
				required: true,
				space: true

			}
			,
			newPassword: {
				required: true,
				space: true

			},
			confirmPassword: {
				required: true,
				space: true,
				equalTo: '#pass'

			}
		},
		messages: {
			currentPassword: {
				required: 'password must be required',
				space: 'space not allowed'

			},
			newPassword: {
				required: 'password must be required',
				space: 'space not allowed'

			},
			confirmPassword: {
				required: 'confirm password must be required',
				space: 'space not allowed',
				equalTo: 'password mismatch'

			}
		}
	})





})



jQuery.validator.addMethod('lettersonly', function(value, element) {
	return /^[^-\s][a-zA-Z_\s-]+$/.test(value);
});

jQuery.validator.addMethod('space', function(value, element) {
	return /^[^-\s]+$/.test(value);
});

jQuery.validator.addMethod('all', function(value, element) {
	return /^[^-\s][a-zA-Z0-9_,.\s-]+$/.test(value);
});


jQuery.validator.addMethod('numericOnly', function(value, element) {
	return /^[0-9]+$/.test(value);
});