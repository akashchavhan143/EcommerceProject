package com.jsp.ecommerce.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.jsp.ecommerce.model.UserDetail;

public interface UserService {

	public UserDetail saveUser(UserDetail details);

	public UserDetail getUserByEmail(String email);

	public void updateUserResetToken(String email, String resetToken);

	public UserDetail getUserByToken(String token);

	public UserDetail upadteUser(UserDetail user);

	public List<UserDetail> getUsers(String role);


	

	public Boolean updateAccountStatus(Integer id, Boolean status);
	
	public UserDetail updateUserProfile(UserDetail user,MultipartFile img);

	public UserDetail saveAdmin(UserDetail user);
	public Boolean existEmail(String email);
}
