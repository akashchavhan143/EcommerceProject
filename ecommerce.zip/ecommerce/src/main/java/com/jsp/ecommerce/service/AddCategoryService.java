package com.jsp.ecommerce.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.jsp.ecommerce.model.AddCategory;

public interface AddCategoryService {

	public AddCategory saveCategory(AddCategory category);

	public boolean existCategory(String name);

	public List<AddCategory> getAllCategory();
	
	public boolean deleteCategory(Integer id);
	
	public AddCategory getCategoryById(Integer id);
	
	public List<AddCategory> getAllActiveCategory();
	
	
	
}
