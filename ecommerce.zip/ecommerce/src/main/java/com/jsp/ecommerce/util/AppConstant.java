package com.jsp.ecommerce.util;

public class AppConstant {

}
