package com.jsp.ecommerce.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.jsp.ecommerce.model.AddCategory;
import com.jsp.ecommerce.model.Product;
import com.jsp.ecommerce.model.ProductOrder;
import com.jsp.ecommerce.model.UserDetail;
import com.jsp.ecommerce.service.AddCategoryService;
import com.jsp.ecommerce.service.CartService;
import com.jsp.ecommerce.service.ProductOrderService;
import com.jsp.ecommerce.service.ProductService;
import com.jsp.ecommerce.service.UserService;
import com.jsp.ecommerce.util.CommonUtil;
import com.jsp.ecommerce.util.OrderStatus;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AddCategoryService categoryService;
	@Autowired
	private UserService userService;

	@Autowired
	private ProductService productService;

	@Autowired
	private CartService cartService;

	@Autowired
	private ProductOrderService orderService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private CommonUtil commonUtil;
	@ModelAttribute
	public void getUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			UserDetail userDetail = userService.getUserByEmail(email);
			m.addAttribute("user", userDetail);
			Integer countCartByUser = cartService.getCountCartByUser(userDetail.getId());
			m.addAttribute("countCartByUser", countCartByUser);
		}
		List<AddCategory> allActiveCategory = categoryService.getAllActiveCategory();
		m.addAttribute("categories", allActiveCategory);
	}

	@GetMapping("/")
	public String index() {
		return "admin/index";
	}

	// add Category module
	@GetMapping("/addCategory")
	public String addCategory(Model m) {
		m.addAttribute("categories", categoryService.getAllCategory());

		return "admin/add_category";
	}

	// --------------

	@PostMapping("/saveCategory")
	public String saveCategory(@ModelAttribute AddCategory category, @RequestParam("file") MultipartFile file,
			HttpSession session, @RequestParam("isActive") Boolean status) throws IOException {

		category.setIsActive(status);
		String imageName = (file != null) ? file.getOriginalFilename() : "default.jpa";
		category.setImageName(imageName);
		if (categoryService.existCategory(category.getCategory())) {
			session.setAttribute("errorMsg", "Category already exist !");
		} else {
			AddCategory saveCategory = categoryService.saveCategory(category);
			if (ObjectUtils.isEmpty(saveCategory)) {
				session.setAttribute("errorMsg", "Internal server error,category not added !");
			} else {
				File saveFile = new ClassPathResource("static/img").getFile();
				Path path = Paths
						.get(saveFile.getAbsolutePath() + File.separator + "category_img" + File.separator + imageName);

				System.out.println(path);
				// Ensure the directory exists
				if (!Files.exists(path.getParent())) {
					Files.createDirectories(path.getParent());
				}

				// Save the file to the destination directory
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				session.setAttribute("succMsg", "Category added Successfully!");
			}

		}

		return "redirect:/admin/addCategory";
	}

	@GetMapping("/deleteCategory/{id}")
	public String deleteCategory(@PathVariable Integer id, HttpSession session) {
		try {
			categoryService.deleteCategory(id);
			session.setAttribute("succMsg", "Category deleted successfully!");
		} catch (Exception e) {
			session.setAttribute("errorMsg", "Category could not be deleted.");
		}
		return "redirect:/admin/addCategory";
	}

	@GetMapping("/loadEditCategory/{id}")
	public String loadEditCategory(@PathVariable Integer id, Model m) {
		m.addAttribute("category", categoryService.getCategoryById(id));
		return "admin/edit_category";
	}

	@PostMapping("/updateCategory")
	public String updateCategory(@ModelAttribute AddCategory category, @RequestParam("file") MultipartFile file,
			HttpSession session, @RequestParam("isActive") Boolean status) throws IOException {
		AddCategory oldCategory = categoryService.getCategoryById(category.getId());
		String imageName = file.isEmpty() ? oldCategory.getImageName() : file.getOriginalFilename();
		if (!ObjectUtils.isEmpty(category)) {
			oldCategory.setCategory(category.getCategory());
			oldCategory.setIsActive(status);
			oldCategory.setImageName(imageName);

		}
		AddCategory updateCategory = categoryService.saveCategory(oldCategory);
		if (!ObjectUtils.isEmpty(updateCategory)) {
			if (!file.isEmpty()) {
				File saveFile = new ClassPathResource("static/img").getFile();
				Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + "category_img" + File.separator
						+ file.getOriginalFilename());

				// Save the file to the destination directory
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			}
			session.setAttribute("succMsg", "Category Updated successfully!");

		} else {
			session.setAttribute("errorMsg", "Category not Updated ,something wrong !");
		}
		return "redirect:/admin/addCategory";
	}

	// add Product module
	@GetMapping("/loadAddProduct")
	public String addProduct(Model m) {
		List<AddCategory> categories = categoryService.getAllCategory();
		m.addAttribute("categories", categories);
		return "admin/add_product";
	}

	@PostMapping("/saveProduct")
	public String saveProduct(@ModelAttribute Product product, @RequestParam("file") MultipartFile image,
			@RequestParam("isActive") Boolean status, HttpSession session) throws IOException {
		// Determine the image name, fallback to "default.jpg" if no image is uploaded
		product.setIsActive(status);
		String imageName = image.isEmpty() ? "default.jpg" : image.getOriginalFilename();

		// Set the image name on the product entity
		product.setImage(imageName);

		product.setDiscountedPrice(product.getPrice() - product.getPrice() * product.getDiscount() * 0.01);
		// Save the product to the database
		Product savedProduct = productService.saveProduct(product);

		// Check if the product was saved successfully
		if (!ObjectUtils.isEmpty(savedProduct)) {
			// Save the image file to the file system only if a new image was uploaded
			if (!image.isEmpty()) {
				// Get the directory where the image will be saved
				File saveFile = new ClassPathResource("static/img").getFile();
				Path path = Paths
						.get(saveFile.getAbsolutePath() + File.separator + "product_img" + File.separator + imageName);

				// Save the image file to the destination directory
				Files.copy(image.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			}

			// Set a success message in the session
			session.setAttribute("succMsg", "Product added successfully!");
		} else {
			// Set an error message if something went wrong
			session.setAttribute("errorMsg", "Product not added, something went wrong!");
		}

		// Redirect back to the product creation page
		return "redirect:/admin/loadAddProduct";
	}

	// View Product module
	@GetMapping("/viewProduct")
	public String viewProduct(Model m) {
		m.addAttribute("products", productService.getAllProduct());
		return "admin/view_product";
	}

	@GetMapping("/deleteProduct/{id}")
	public String deleteProduct(@PathVariable Integer id, HttpSession session) {
		try {
			productService.deleteProduct(id);
			session.setAttribute("succMsg", "Product deleted successfully!");
		} catch (Exception e) {
			session.setAttribute("errorMsg", "Product could not be deleted.!");
		}
		return "redirect:/admin/viewProduct";
	}

	@GetMapping("/loadEditProduct/{id}")
	public String loadEditProduct(@PathVariable Integer id, Model m) {
		m.addAttribute("product", productService.getProductById(id));
		m.addAttribute("categories", categoryService.getAllCategory());
		return "admin/edit_Product";
	}

	@PostMapping("/updateProduct")
	public String updateProduct(@ModelAttribute Product product, @RequestParam("file") MultipartFile image, Model m,
			HttpSession session, @RequestParam("isActive") Boolean status) {

		Product updateProduct = productService.updateProduct(product, image, status);

		if (!ObjectUtils.isEmpty(updateProduct)) {

			session.setAttribute("succMsg", "Product Updated successfully!");
		} else {
			session.setAttribute("errorMsg", "Product not Updated ,something went wrong !");
		}
		return "redirect:/admin/viewProduct";
	}

	@GetMapping("/addAdmin")
	public String addAdmin(Model m) {
		List<UserDetail> admins = userService.getUsers("ROLE_ADMIN");
		m.addAttribute("admins", admins);
		return "admin/add_admin";
	}

	@GetMapping("/updateAdminStatus")
	public String updateAdminAccountStatus(@RequestParam Integer id, @RequestParam Boolean status,
			HttpSession session) {
		Boolean f = userService.updateAccountStatus(id, status);
		if (f) {
			session.setAttribute("succMsg", "Account status updated successfully!");
		} else {
			session.setAttribute("errorMsg", "Account status update Unsuccessfull !");
		}
		return "redirect:/admin/addAdmin";
	}

	@GetMapping("/users")
	public String getAllUsers(Model m) {
		List<UserDetail> users = userService.getUsers("ROLE_USER");
		m.addAttribute("users", users);

		return "admin/users";
	}

	@GetMapping("/updateStatus")
	public String updateAccountStatus(@RequestParam Integer id, @RequestParam Boolean status, HttpSession session) {
		Boolean f = userService.updateAccountStatus(id, status);
		if (f) {
			session.setAttribute("succMsg", "Account status updated successfully!");
		} else {
			session.setAttribute("errorMsg", "Account status update Unsuccessfull !");
		}
		return "redirect:/admin/users";
	}

	@GetMapping("/orders")
	public String orders(Model m) {
		List<ProductOrder> orders = orderService.getAllOrders();
		m.addAttribute("orders", orders);
		m.addAttribute("srch", false);
		return "admin/orders";
	}

	@PostMapping("/updateOrderStatus")
	public String updateOrderStatus(@RequestParam Integer id, @RequestParam Integer st, HttpSession session) {
		OrderStatus[] values = OrderStatus.values();
		String status = null;
		for (OrderStatus orderStatus : values) {

			if (orderStatus.getId().equals(st)) {
				status = orderStatus.getName();
			}
		}
		Boolean orderStatus = orderService.orderStatus(id, status);
		if (orderStatus) {
			session.setAttribute("succMsg", "Status updated successfully!");
		} else {
			session.setAttribute("errorMsg", "Status not updated, something went wrong");
		}
		return "redirect:/admin/orders";
	}

	@GetMapping("/searchOrder")
	public String searchOrder(@RequestParam String orderId, Model m, HttpSession session) {
		ProductOrder searchOrder = orderService.searchOrderByOrderId(orderId.trim());
		if(!orderId.isBlank()) { 
			if (ObjectUtils.isEmpty(searchOrder)) {
				session.setAttribute("errorMsg", "No Order found with this Order Id");
				m.addAttribute("order", null);
			} else {
				m.addAttribute("order", searchOrder);
				
			}
			m.addAttribute("srch", true);
		}else{
			List<ProductOrder> orders = orderService.getAllOrders();
			m.addAttribute("orders", orders);
			m.addAttribute("srch", false);
		}
			
			
		return "admin/orders";

	}
	
	@PostMapping("/saveAdmin")
    public String saveUser(@ModelAttribute UserDetail user,@RequestParam("img")MultipartFile file,HttpSession session) throws IOException {
		String imageName=file.isEmpty()?"default.jpg":file.getOriginalFilename();
		user.setProfileImage(imageName);
		UserDetail saveAdmin = userService.saveAdmin(user);
		
		if(!ObjectUtils.isEmpty(saveAdmin)) {
			if (!file.isEmpty()) {
				// Get the directory where the image will be saved
				File saveFile = new ClassPathResource("static/img").getFile();
				Path path = Paths
						.get(saveFile.getAbsolutePath() + File.separator + "profile_img" + File.separator + file.getOriginalFilename());

				// Save the image file to the destination directory
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			}

			// Set a success message in the session
			session.setAttribute("succMsg", "Admin added Successfull !");
			
		}else{
			session.setAttribute("errorMsg", "Admin not added ,something went wrong !");
		}
    	return "redirect:/admin/addAdmin";
    }

	@GetMapping("/profile")
	public String loadProfilePage() {
		return "admin/profile";
	}
	
	@GetMapping("/editProfilePage")
	public String loadEditProfilePage() {
		return "admin/edit_profile";
	}
	
	@PostMapping("/updateProfile")
	public String updateProfile(@ModelAttribute UserDetail user,@RequestParam MultipartFile img,HttpSession session) {
		
		UserDetail updateUserProfile = userService.updateUserProfile(user, img);
		if (ObjectUtils.isEmpty(updateUserProfile)){
			session.setAttribute("errorMsg", "Profile not updated !!Something went wrong on server");
		} else {
			session.setAttribute("succMsg", "Profile  updated sucessfully");
		}
		return "redirect:/admin/editProfilePage";
	}
	
	@GetMapping("/changePasswordPage")
	public String loadChangePasswordPage() {
		return "admin/change_password";
	}
	
	@PostMapping("/changePassword")
	public String changePassword(@RequestParam String newPassword, @RequestParam String currentPassword, Principal p,
			HttpSession session) {
		UserDetail loggedInUserDetails =commonUtil.getLoggedInUser(p);

		Boolean matches = passwordEncoder.matches(currentPassword, loggedInUserDetails.getPassword());

		if (matches) {
			String encodePassword = passwordEncoder.encode(newPassword);
			loggedInUserDetails.setPassword(encodePassword);
			UserDetail updateUser = userService.upadteUser(loggedInUserDetails);
			if (ObjectUtils.isEmpty(updateUser)) {
				session.setAttribute("errorMsg", "Password not changed !! Error in server");
			} else {
				session.setAttribute("succMsg", "Password changed sucessfully");
			}
		} else {
			session.setAttribute("errorMsg", "Current Password incorrect");
		}

		return "redirect:/admin/changePasswordPage";
	}
}
