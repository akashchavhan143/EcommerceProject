package com.jsp.ecommerce.service.imp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.jsp.ecommerce.model.Cart;
import com.jsp.ecommerce.model.Product;
import com.jsp.ecommerce.model.UserDetail;
import com.jsp.ecommerce.repository.CartRepository;
import com.jsp.ecommerce.repository.ProductRepository;
import com.jsp.ecommerce.repository.UserRepository;
import com.jsp.ecommerce.service.CartService;

@Service
public class CartServiceImp implements CartService {

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ProductRepository productRepository;

	@Override
	public Cart saveCart(Integer productId, Integer userId) {
		UserDetail userDetail = userRepository.findById(userId).get();
		Product product = productRepository.findById(productId).get();
		
		Cart cartStatus = cartRepository.findByProductIdAndUserId(productId, userId);
		Cart cart=null;
		
		if(ObjectUtils.isEmpty(cartStatus)) {
			cart=new Cart();
			cart.setProduct(product);
			cart.setUser(userDetail);
			cart.setQuantity(1);
			cart.setTotalPrice(1*product.getDiscountedPrice());
		}else {
			
			cart=cartStatus;
			
			if(product.getStock()>cart.getQuantity()) {
				cart.setQuantity(cart.getQuantity()+1);
				cart.setTotalPrice(cart.getQuantity()*cart.getProduct().getDiscountedPrice());
			}
			
			
		}
		Cart saveCart= cartRepository.save(cart);

		return saveCart;
	}

	@Override
	public List<Cart> getCartByUser(Integer userId) {
		
		List<Cart> carts = cartRepository.findByUserId(userId);

		Double totalOrderPrice = 0.0;
		List<Cart> updateCarts = new ArrayList<>();
		for (Cart c : carts) {
			Double totalPrice = (c.getProduct().getDiscountedPrice() * c.getQuantity());
			c.setTotalPrice(totalPrice);
			totalOrderPrice = totalOrderPrice + totalPrice;
			c.setTotalOrderPrice(totalOrderPrice);
			updateCarts.add(c);
		}
		
		return updateCarts;
	}

	@Override
	public Integer getCountCartByUser(Integer userId) {
		
		return cartRepository.countByUserId(userId);
	}
	
	@Override
	public void updateQuantity(String sy, Integer cid) {

		Cart cart = cartRepository.findById(cid).get();
		Product product = cart.getProduct();
		int updateQuantity=cart.getQuantity();

		if (sy.equalsIgnoreCase("de")) {
			updateQuantity = cart.getQuantity() - 1;

			if (updateQuantity <= 0) {
				cartRepository.delete(cart);
			} else {
				cart.setQuantity(updateQuantity);
				cartRepository.save(cart);
			}

		} else {
			
			if(product.getStock()>updateQuantity) {
				updateQuantity = cart.getQuantity() + 1;
				cart.setQuantity(updateQuantity);
				cartRepository.save(cart);
			}
			
		}

	}
	
	@Override
	public boolean removeById(Integer id) {
		Cart cart = cartRepository.findById(id).orElse(null);
		if (cart!=null) {
			cartRepository.delete(cart);
			return true;
		}
		return false;
	}

}
