package com.jsp.ecommerce.service.imp;

import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.jsp.ecommerce.service.CommonService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Service
public class CommonServiceImp implements CommonService {

	@Override
	public void removeSessionMsg() {

		HttpServletRequest request = ((ServletRequestAttributes)( RequestContextHolder.getRequestAttributes()))
				.getRequest();
		HttpSession session = request.getSession();
		session.removeAttribute("errorMsg");
		session.removeAttribute("succMsg");
	}

}
