package com.jsp.ecommerce.service.imp;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.ecommerce.model.Cart;
import com.jsp.ecommerce.model.OrderAddress;
import com.jsp.ecommerce.model.OrderRequest;
import com.jsp.ecommerce.model.Product;
import com.jsp.ecommerce.model.ProductOrder;
import com.jsp.ecommerce.repository.CartRepository;
import com.jsp.ecommerce.repository.ProductOrderRepository;
import com.jsp.ecommerce.repository.ProductRepository;
import com.jsp.ecommerce.service.ProductOrderService;
import com.jsp.ecommerce.util.OrderStatus;

@Service
public class ProductOrderServiceImp implements ProductOrderService {
	@Autowired
	private ProductOrderRepository orderRepository;

	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private ProductRepository productRepository;
	

	@Override
	public void saveOrder(Integer userId, OrderRequest orderRequest) {
		List<Cart> carts = cartRepository.findByUserId(userId);
		for (Cart cart : carts) {
			ProductOrder order = new ProductOrder();
			order.setOrderId(UUID.randomUUID().toString());

			order.setOderDate(LocalDate.now());
			
			Product product = cart.getProduct();
	        order.setProduct(product);

			order.setProduct(cart.getProduct());

			order.setPrice(cart.getProduct().getDiscountedPrice());
			order.setQauntity(cart.getQuantity());
			order.setUser(cart.getUser());
			order.setStatus(OrderStatus.IN_PRGRESS.getName());
			order.setPaymentType(orderRequest.getPaymentType());
			OrderAddress address = new OrderAddress();

			address.setFirstName(orderRequest.getFirstName());
			address.setLastName(orderRequest.getLastName());
			address.setEmail(orderRequest.getEmail());
			address.setMobile(orderRequest.getMobile());
			address.setAddress(orderRequest.getAddress());
			address.setCity(orderRequest.getCity());
			address.setState(orderRequest.getState());
			address.setPincode(orderRequest.getPincode());
			order.setOrderAddress(address);
            
			//save order
			ProductOrder save = orderRepository.save(order);
			
			// Reduce stock
	        Integer currentStock = product.getStock();  // Using Integer
	        Integer quantityOrdered = cart.getQuantity();  // Using Integer

	        if (currentStock != null && quantityOrdered != null && quantityOrdered <= currentStock) {
	            product.setStock(currentStock - quantityOrdered);
	            productRepository.save(product);  
	        } else {
	            throw new IllegalStateException("Not enough stock for product: " + product.getTitle());
	        }
			
			
			
			//delete the cart after successfull saveOrder
			cartRepository.delete(cart);
		}
		
	}

	@Override
	public List<ProductOrder> getOrdersByUser(Integer userId) {
		List<ProductOrder> orders = orderRepository.findByUserId(userId);
		return orders;
	}

	@Override
	public Boolean orderStatus(Integer id, String status) {
		Optional<ProductOrder> findById = orderRepository.findById(id);
		if (findById.isPresent()) {
			ProductOrder order = findById.get();
			order.setStatus(status);
			orderRepository.save(order);
			return true;
		}
		return false;
	}

	@Override
	public List<ProductOrder> getAllOrders() {
		List<ProductOrder> orders = orderRepository.findAll();
		return orders;
	}

	@Override
	public ProductOrder searchOrderByOrderId(String orderId) {
		
		return orderRepository.findByOrderId(orderId);
	}
}
