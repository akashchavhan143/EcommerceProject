package com.jsp.ecommerce.service.imp;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;

import com.jsp.ecommerce.model.UserDetail;
import com.jsp.ecommerce.repository.UserRepository;
import com.jsp.ecommerce.service.UserService;

@Service
public class UserServiceImp implements UserService{
	
	@Autowired
    private UserRepository   userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	public UserDetail saveUser(UserDetail user) {
		user.setRole("ROLE_USER");
		user.setIsEnable(true);
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		UserDetail saveUser= userRepository.save(user);
		return saveUser;
	}
	@Override
	public UserDetail getUserByEmail(String email) {
		
		return userRepository.findByEmail(email);
	}
	@Override
	public void updateUserResetToken(String email, String resetToken) {
		UserDetail findByEmail = userRepository.findByEmail(email);
		findByEmail.setResetToken(resetToken);
		userRepository.save(findByEmail);
		
	}
	@Override
	public UserDetail getUserByToken(String token) {
		
		return userRepository.findByResetToken(token);
	}
	@Override
	public UserDetail upadteUser(UserDetail user) {
		
		return userRepository.save(user);
	}
	@Override
	public List<UserDetail> getUsers(String role) {
		
		return userRepository.findByRole(role);
	}
	@Override
	public Boolean updateAccountStatus(Integer id, Boolean status) {
		Optional<UserDetail> findById = userRepository.findById(id);
		if(findById.isPresent()) {
			UserDetail userDetail = findById.get();
			userDetail.setIsEnable(status);
			userRepository.save(userDetail);
			return true;
		}
		return false;
	}
	
	@Override
	public UserDetail updateUserProfile(UserDetail user,MultipartFile img) {
		UserDetail dbUser= userRepository.findById(user.getId()).get();
		if(!img.isEmpty()) {
			dbUser.setProfileImage(img.getOriginalFilename());
		}
		if(!ObjectUtils.isEmpty(dbUser)) {
			dbUser.setName(user.getName());
			dbUser.setMobile(user.getMobile());
			dbUser.setAddress(user.getAddress());
			dbUser.setCity(user.getCity());
			dbUser.setState(user.getState());
			dbUser.setPincode(user.getPincode());
			dbUser=userRepository.save(dbUser);
		}
		
		try {
			if (!img.isEmpty()) {
				// Get the directory where the image will be saved
				File saveFile = new ClassPathResource("static/img").getFile();
				Path path = Paths
						.get(saveFile.getAbsolutePath() + File.separator + "profile_img" + File.separator + img.getOriginalFilename());

				// Save the image file to the destination directory
				Files.copy(img.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (Exception e) {
		e.printStackTrace();
		}
		
		return dbUser;
	}
    
	
	@Override
	public UserDetail saveAdmin(UserDetail user) {
		user.setRole("ROLE_ADMIN");
		user.setIsEnable(true);
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		UserDetail saveUser= userRepository.save(user);
		return saveUser;
	}
	@Override
	public Boolean existEmail(String email) {
		
		return userRepository.existsByEmail(email);
	}
}
