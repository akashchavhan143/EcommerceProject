package com.jsp.ecommerce.util;

import java.io.UnsupportedEncodingException;
import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.jsp.ecommerce.model.UserDetail;
import com.jsp.ecommerce.service.UserService;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpServletRequest;

@Component
public class CommonUtil {

	@Autowired
	private  JavaMailSender mailSender;
	@Autowired
	private  UserService userService ;

	public  boolean sendMail(String url,String reciepentEmail) throws UnsupportedEncodingException, MessagingException {
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper=new MimeMessageHelper(message);
		helper.setFrom("akashchavhan512786@gmail.com", "BuyZone.com");
		helper.setTo(reciepentEmail);
		String content="<p>hello </p>"+"<p>You have requested to reset password</p>"+"<p>Click the link bellow to change your password:</p>"
		+"<p><a href=\""+url+"\">change my password</a></p>";
		helper.setSubject("password Reset");
		helper.setText(content,true);
		mailSender.send(message);
		return true;
	}

	public static String generateUrl(HttpServletRequest request) {

		// http://localhost:8080/forgotPassword
		String siteUrl = request.getRequestURI();
		

		return siteUrl.replace(request.getServletPath(), "");
	}
	
	public UserDetail getLoggedInUser(Principal p) {
		String email = p.getName();
		UserDetail userDetail = userService.getUserByEmail(email);
		return userDetail;
	}

}
