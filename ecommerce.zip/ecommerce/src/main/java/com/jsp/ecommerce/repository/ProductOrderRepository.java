package com.jsp.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.ecommerce.model.ProductOrder;

public interface ProductOrderRepository extends JpaRepository<ProductOrder, Integer> {

	public List<ProductOrder> findByUserId(Integer userId);

	public ProductOrder findByOrderId(String orderId);

	

}
