package com.jsp.ecommerce.controller;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.jsp.ecommerce.model.AddCategory;
import com.jsp.ecommerce.model.Product;
import com.jsp.ecommerce.model.UserDetail;
import com.jsp.ecommerce.model.WishList;
import com.jsp.ecommerce.repository.UserRepository;
import com.jsp.ecommerce.service.AddCategoryService;
import com.jsp.ecommerce.service.CartService;
import com.jsp.ecommerce.service.ProductService;
import com.jsp.ecommerce.service.UserService;
import com.jsp.ecommerce.service.WishListService;
import com.jsp.ecommerce.util.CommonUtil;

import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

	@Autowired
	private AddCategoryService categoryService;

	@Autowired
	private ProductService productService;

	@Autowired
	private UserService userService;

	@Autowired
	private CommonUtil commonUtil;
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private CartService cartService;

	@Autowired
	private WishListService wishListService;

	@ModelAttribute
	public void getUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			UserDetail userDetail = userService.getUserByEmail(email);
			m.addAttribute("user", userDetail);
			Integer countCartByUser = cartService.getCountCartByUser(userDetail.getId());
			m.addAttribute("countCartByUser", countCartByUser);
		}
		List<AddCategory> allActiveCategory = categoryService.getAllActiveCategory();
		m.addAttribute("categories", allActiveCategory);
	}

	@GetMapping("/")
	public String index(Model m) {
		List<Product> products = productService.getAllActiveProduct("").stream()
				.sorted((p1, p2) -> p2.getId().compareTo(p1.getId())).limit(8).toList();
		m.addAttribute("products", products);
		return "index";
	}

	@GetMapping("/signin")
	public String login() {
		return "login";
	}

	@GetMapping("/register")
	public String register() {
		return "register";
	}

	@GetMapping("/demo")
	public String demo() {
		return "demo";
	}

	@GetMapping("/products")
	public String products(Model m, @RequestParam(value = "category", defaultValue = "") String category,
			@RequestParam(name = "pageNo", defaultValue = "0") Integer pageNo,
			@RequestParam(name = "pageSize", defaultValue = "4") Integer pageSize) {
		// System.out.println("category="+category);
		List<AddCategory> categories = categoryService.getAllActiveCategory();
		m.addAttribute("categories", categories);

		List<Product> products = productService.getAllActiveProduct(category);
		m.addAttribute("products", products);

		m.addAttribute("paramValue", category);

		return "product";
	}

	@GetMapping("product/{id}")
	public String viewProduct(Model m, @PathVariable Integer id) {
		// m.addAttribute("category",categoryService.getCategoryById());
		m.addAttribute("product", productService.getProductById(id));
		return "view_product";
	}

	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute UserDetail user, @RequestParam("img") MultipartFile file,
			HttpSession session) throws IOException {

		if (userService.existEmail(user.getEmail())) {
			session.setAttribute("errorMsg", "Email already exist,Try to login with email and password !");
		} else {
			String imageName = file.isEmpty() ? "default.jpg" : file.getOriginalFilename();
			user.setProfileImage(imageName);
			UserDetail saveUser = userService.saveUser(user);

			if (!ObjectUtils.isEmpty(saveUser)) {
				if (!file.isEmpty()) {
					// Get the directory where the image will be saved
					File saveFile = new ClassPathResource("static/img").getFile();
					Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + "profile_img" + File.separator
							+ file.getOriginalFilename());

					// Save the image file to the destination directory
					Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				}

				// Set a success message in the session
				session.setAttribute("succMsg", "Registration Successfull !");

			} else {
				session.setAttribute("errorMsg", "Registration Unsuccessfull,something went wrong !");
			}
		}

		return "redirect:/register";
	}

	// forget password module
	@GetMapping("/forgotPassword")
	public String showForgotPassword() {
		return "forgot_password";
	}

	@PostMapping("/forgotPassword")
	public String processForgotPassword(@RequestParam String email, HttpSession session, HttpServletRequest request)
			throws UnsupportedEncodingException, MessagingException {
		UserDetail userByEmail = userService.getUserByEmail(email);
		if (ObjectUtils.isEmpty(userByEmail)) {
			session.setAttribute("errorMsg", "Invalid Email");
		} else {
			String resetToken = UUID.randomUUID().toString();
			userService.updateUserResetToken(email, resetToken);
			// generate url http://localhost:8080/forgotPassword?token
			// "http://localhost:8080/"+

			String url = "http://localhost:8080/" + CommonUtil.generateUrl(request) + "reset-password?token="
					+ resetToken;
			Boolean sendMail = commonUtil.sendMail(url, email);
			if (sendMail) {
				session.setAttribute("succMsg", "Please check email,Password reset link sent on it");
			} else {
				session.setAttribute("errorMsg", "Something went wrong on server,mail not sent");
			}
		}
		return "redirect:/forgotPassword";
	}

	@GetMapping("/reset-password")
	public String showResetPassword(@RequestParam String token, HttpSession session, Model m) {

		UserDetail userByToken = userService.getUserByToken(token);
		if (userByToken == null) {
			m.addAttribute("msg", "Invalid Link or expired !!");
			return "message";
		}
		m.addAttribute("token", token);
		return "reset_password";
	}

	@PostMapping("/reset-password")
	public String resetPassword(@RequestParam String token, @RequestParam String password, HttpSession session,
			Model m) {

		UserDetail userByToken = userService.getUserByToken(token);
		if (userByToken == null) {
			m.addAttribute("msg", "Invalid Link or expired !!");
			return "message";
		} else {
			userByToken.setPassword(passwordEncoder.encode(password));
			userByToken.setResetToken(null);
			userService.upadteUser(userByToken);
			session.setAttribute("succMsg", "password change successfull");
			// m.addAttribute("msg","password change successfull !!");
			return "redirect:/signin";
		}

	}

	@GetMapping("/search")
	public String searchProduct(@RequestParam String search, Model m) {
		List<Product> searchProduct = productService.searchProduct(search);
		m.addAttribute("products", searchProduct);
		return "product";

	}
}
