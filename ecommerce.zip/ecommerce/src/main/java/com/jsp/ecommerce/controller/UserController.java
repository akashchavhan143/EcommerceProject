package com.jsp.ecommerce.controller;

import java.security.Principal;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.jsp.ecommerce.model.AddCategory;
import com.jsp.ecommerce.model.Cart;
import com.jsp.ecommerce.model.OrderRequest;
import com.jsp.ecommerce.model.ProductOrder;
import com.jsp.ecommerce.model.UserDetail;
import com.jsp.ecommerce.model.WishList;
import com.jsp.ecommerce.service.AddCategoryService;
import com.jsp.ecommerce.service.CartService;
import com.jsp.ecommerce.service.ProductOrderService;
import com.jsp.ecommerce.service.UserService;
import com.jsp.ecommerce.service.WishListService;
import com.jsp.ecommerce.util.OrderStatus;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private AddCategoryService categoryService;

	@Autowired
	private UserService userService;

	@Autowired
	private CartService cartService;

	@Autowired
	private ProductOrderService orderService;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private WishListService wishListService;

	@GetMapping("/")
	public String home() {

		return "user/home";
	}

	@ModelAttribute
	public void getUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			UserDetail userDetail = userService.getUserByEmail(email);
			m.addAttribute("user", userDetail);
			Integer countCartByUser = cartService.getCountCartByUser(userDetail.getId());
			m.addAttribute("countCartByUser", countCartByUser);
		}
		List<AddCategory> allActiveCategory = categoryService.getAllActiveCategory();
		m.addAttribute("categories", allActiveCategory);

	}

	@GetMapping("/addCart")
	public String addTocard(@RequestParam Integer pid, @RequestParam Integer uid, HttpSession session) {
		Cart saveCart = cartService.saveCart(pid, uid);
		if (ObjectUtils.isEmpty(saveCart)) {
			session.setAttribute("errorMsg", "Product not added to cart,something went wrong !");
		} else {
			session.setAttribute("succMsg", "Product added to cart,ChearUp  !");
		}
		return "redirect:/product/" + pid;
	}

	@GetMapping("/cart")
	public String loadCartPage(Principal p, Model m) {

		UserDetail user = getLoggedInUser(p);
		List<Cart> carts = cartService.getCartByUser(user.getId());

		m.addAttribute("carts", carts);
		Double totalOrderPrice = 0.0;
		if (carts.size() > 0) {
			totalOrderPrice = carts.get(carts.size() - 1).getTotalOrderPrice();
			Integer item = carts.size();
			m.addAttribute("totalOrderPrice", totalOrderPrice);
			m.addAttribute("item", item);
		}
		return "/user/cart";
	}

	@GetMapping("/cartQuantityUpdate")
	public String updateCartQuantity(@RequestParam String sy, @RequestParam Integer cid) {
		cartService.updateQuantity(sy, cid);
		return "redirect:/user/cart";
	}

	private UserDetail getLoggedInUser(Principal p) {
		String email = p.getName();
		UserDetail userDetail = userService.getUserByEmail(email);
		return userDetail;
	}

	@GetMapping("/removeCart/{id}")
	public String removeCart(@PathVariable Integer id, HttpSession session) {
		try {
			cartService.removeById(id);
			session.setAttribute("succMsg", "Cart removed successfully!");
		} catch (Exception e) {
			session.setAttribute("errorMsg", "Cart could not be removed !!,something went wrong");
		}
		return "redirect:/user/cart";
	}

	@GetMapping("/orders")
	public String orderPage(Model m, Principal p) {
		UserDetail user = getLoggedInUser(p);
		List<Cart> carts = cartService.getCartByUser(user.getId());

		m.addAttribute("carts", carts);
		Double totalOrderPrice = 0.0;
		if (carts.size() > 0) {
			totalOrderPrice = carts.get(carts.size() - 1).getTotalOrderPrice();
			Integer item = carts.size();
			m.addAttribute("totalOrderPrice", totalOrderPrice);
			m.addAttribute("item", item);
		}
		return "user/order";
	}

	@GetMapping("/success")
	public String loadSuccess() {
		return "user/success";
	}

	@PostMapping("/saveOrder")
	public String saveOrder(@ModelAttribute OrderRequest orderRequest, Principal p) {
		// System.out.println(orderRequest);
		UserDetail user = getLoggedInUser(p);
		orderService.saveOrder(user.getId(), orderRequest);

		return "redirect:/user/success";
	}

	@GetMapping("/userOrders")
	public String loadUserOrders(Model m, Principal p) {
		UserDetail user = getLoggedInUser(p);
		List<ProductOrder> orders = orderService.getOrdersByUser(user.getId());
		m.addAttribute("orders", orders);
		return "user/my_orders";
	}

	@GetMapping("/udateStatus")
	public String updateOrderStatus(@RequestParam Integer id, @RequestParam Integer st, HttpSession session) {
		OrderStatus[] values = OrderStatus.values();
		String status = null;
		for (OrderStatus orderStatus : values) {

			if (orderStatus.getId().equals(st)) {
				status = orderStatus.getName();
			}
		}
		Boolean orderStatus = orderService.orderStatus(id, status);
		if (orderStatus) {
			session.setAttribute("succMsg", "Product Cancelled successfully!");
		} else {
			session.setAttribute("errorMsg", "Product not Cancelled, something went wrong");
		}
		return "redirect:/user/userOrders";
	}

	@GetMapping("/profile")
	public String loadProfilePage() {
		return "user/profile";
	}

	@GetMapping("/editProfilePage")
	public String loadEditProfilePage() {
		return "user/edit_profile";
	}

	@PostMapping("/updateProfile")
	public String updateProfile(@ModelAttribute UserDetail user, @RequestParam MultipartFile img, HttpSession session) {

		UserDetail updateUserProfile = userService.updateUserProfile(user, img);
		if (ObjectUtils.isEmpty(updateUserProfile)) {
			session.setAttribute("errorMsg", "Profile not updated !!Something went wrong on server");
		} else {
			session.setAttribute("succMsg", "Profile  updated sucessfully");
		}
		return "redirect:/user/editProfilePage";
	}

	@GetMapping("/changePasswordPage")
	public String loadChangePasswordPage() {
		return "user/change_password";
	}

	@PostMapping("/changePassword")
	public String changePassword(@RequestParam String newPassword, @RequestParam String currentPassword, Principal p,
			HttpSession session) {
		UserDetail loggedInUserDetails = getLoggedInUser(p);

		Boolean matches = passwordEncoder.matches(currentPassword, loggedInUserDetails.getPassword());

		if (matches) {
			String encodePassword = passwordEncoder.encode(newPassword);
			loggedInUserDetails.setPassword(encodePassword);
			UserDetail updateUser = userService.upadteUser(loggedInUserDetails);
			if (ObjectUtils.isEmpty(updateUser)) {
				session.setAttribute("errorMsg", "Password not changed !! Error in server");
			} else {
				session.setAttribute("succMsg", "Password changed sucessfully");
			}
		} else {
			session.setAttribute("errorMsg", "Current Password incorrect");
		}

		return "redirect:/user/changePasswordPage";
	}

	@PostMapping("/saveWishList")
	public String saveWishList() {

		return null;
	}

	@GetMapping("/saveWishList")
	public String saveWishList(@RequestParam Integer pid, @RequestParam Integer uid, HttpSession session,Model m) {
		WishList saveWishList = wishListService.saveWishList(pid, uid);
		
		
		if (ObjectUtils.isEmpty(saveWishList)) {
			session.setAttribute("errorMsg", "Product removed from wishList !");
		} else {
			session.setAttribute("succMsg", "Product added to wishlist,chear Up  !");
		}
		return "redirect:/products";
	}

	@GetMapping("/wishlist")
	public String getWishlistPage(Principal p, Model m) {
        
		UserDetail user = getLoggedInUser(p);
		
		List<WishList> wishList = wishListService.getWishListByUser(user.getId());
		
		//System.out.println(wishList);
		
		m.addAttribute("wishList", wishList);
	
		return "/user/wishlist";
	}
	
	
	
	@GetMapping("/removeWishList/{id}")
	public String removeWishList(@PathVariable Integer id, HttpSession session) {
		try {
			wishListService.removeWishListById(id);
			session.setAttribute("succMsg", "Product removed from wishlist successfully!");
		} catch (Exception e) {
			session.setAttribute("errorMsg", "product could not be removed from wishlist!!,something went wrong");
		}
		return "redirect:/user/wishlist";
	}
	
	
	
}
