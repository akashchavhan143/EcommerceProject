package com.jsp.ecommerce.service;

import java.util.List;

import com.jsp.ecommerce.model.Cart;

public interface CartService {

	public Cart saveCart(Integer productId, Integer userId);

	public List<Cart> getCartByUser(Integer userId);
	public Integer getCountCartByUser(Integer userId);

	public void updateQuantity(String sy, Integer cid);

	public boolean removeById(Integer id);

}
