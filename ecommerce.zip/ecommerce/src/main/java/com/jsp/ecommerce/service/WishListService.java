package com.jsp.ecommerce.service;

import java.util.List;

import com.jsp.ecommerce.model.WishList;

public interface WishListService {

	public WishList saveWishList(Integer productId, Integer userId);

	public List<WishList> getWishListByUser(Integer id);
	
	public Boolean removeWishListById(Integer id);

	public Boolean likeStatus(Integer productId, Integer userId);

	public WishList getWishListStatus(Integer productId, Integer userId);

}
