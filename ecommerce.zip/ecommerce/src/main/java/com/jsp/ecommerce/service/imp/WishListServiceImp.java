package com.jsp.ecommerce.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.jsp.ecommerce.model.Product;
import com.jsp.ecommerce.model.UserDetail;
import com.jsp.ecommerce.model.WishList;
import com.jsp.ecommerce.repository.ProductRepository;
import com.jsp.ecommerce.repository.UserRepository;
import com.jsp.ecommerce.repository.WishListRepository;
import com.jsp.ecommerce.service.WishListService;

@Service
public class WishListServiceImp implements WishListService {
	@Autowired
	private WishListRepository wishListRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ProductRepository productRepository;

	@Override
	public WishList saveWishList(Integer productId, Integer userId) {

		UserDetail userDetail = userRepository.findById(userId).get();

		Product product = productRepository.findById(productId).get();

		WishList wishListStaus = wishListRepository.findByProductIdAndUserId(productId, userId);

		WishList wishList = null;

		if (ObjectUtils.isEmpty(wishListStaus)) {
			wishList = new WishList();
			wishList.setProduct(product);
			wishList.setUser(userDetail);
            
            
			return wishListRepository.save(wishList);
		} else {
			 wishListRepository.delete(wishListStaus);
			 return null;
		}
	}

	@Override
	public List<WishList> getWishListByUser(Integer id) {
		List<WishList> wishListfindByUserId = wishListRepository.findByUserId(id);

		return wishListfindByUserId;
	}

	@Override
	public Boolean removeWishListById(Integer id) {
		
		WishList wishList = wishListRepository.findById(id).orElse(null);
		if(wishList!=null){
			wishListRepository.delete(wishList);
			return true;
		}
		
		return false;			
	}
	
	@Override
	public Boolean likeStatus(Integer productId,Integer userId) {
		UserDetail userDetail = userRepository.findById(userId).get();

		Product product = productRepository.findById(productId).get();

		WishList wishListStaus = wishListRepository.findByProductIdAndUserId(productId, userId);
		if(wishListStaus!=null) {
			
			return true;
		}
		return false;
	}
	
	@Override
	public WishList getWishListStatus(Integer productId, Integer userId) {
	    return wishListRepository.findByProductIdAndUserId(productId, userId);
	}

}
