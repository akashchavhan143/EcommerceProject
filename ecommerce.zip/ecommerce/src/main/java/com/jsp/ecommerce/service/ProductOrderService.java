package com.jsp.ecommerce.service;

import java.util.List;

import com.jsp.ecommerce.model.OrderRequest;
import com.jsp.ecommerce.model.ProductOrder;

public interface ProductOrderService {

	public void saveOrder(Integer userId,OrderRequest orderRequest);
	
	public List<ProductOrder> getOrdersByUser(Integer userId);
	
	public Boolean orderStatus(Integer id,String status);
	
	public List<ProductOrder> getAllOrders();

	public ProductOrder searchOrderByOrderId(String orderId);
	
}
