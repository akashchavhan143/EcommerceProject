package com.jsp.ecommerce.service;

import org.springframework.stereotype.Service;

@Service
public interface CommonService {
	
	public void removeSessionMsg();

}
