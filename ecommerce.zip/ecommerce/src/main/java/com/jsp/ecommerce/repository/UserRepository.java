package com.jsp.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.ecommerce.model.UserDetail;

public interface UserRepository extends JpaRepository<UserDetail, Integer>{

	public UserDetail findByEmail(String username);
	public UserDetail findByResetToken(String resetToken);
	
	public List<UserDetail> findByRole(String role);
	
	public Boolean existsByEmail(String email);

	

}
