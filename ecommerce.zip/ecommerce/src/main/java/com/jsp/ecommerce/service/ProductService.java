package com.jsp.ecommerce.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import com.jsp.ecommerce.model.Product;


public interface ProductService {
	public Product saveProduct(Product product);

	public List<Product> getAllProduct();

	public boolean deleteProduct(Integer id);
	
	public Product getProductById(Integer id);
	
    public Product updateProduct(Product product,MultipartFile image, Boolean status);

	public List<Product> getAllActiveProduct(String category);
	
	public List<Product> searchProduct(String search);
	
	
	
	
	
}
