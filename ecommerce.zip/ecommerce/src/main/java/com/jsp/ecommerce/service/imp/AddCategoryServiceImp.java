package com.jsp.ecommerce.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.ecommerce.model.AddCategory;
import com.jsp.ecommerce.repository.AddCategoryRepository;
import com.jsp.ecommerce.service.AddCategoryService;

@Service
public class AddCategoryServiceImp implements AddCategoryService {
	
	@Autowired
    private AddCategoryRepository addCategoryRepository;
    
	@Override
	public AddCategory saveCategory(AddCategory category) {
		
		return addCategoryRepository.save(category);
	}
	
	

	@Override
	public List<AddCategory> getAllCategory() {
		
		return addCategoryRepository.findAll();
	}
	
	@Override
	public boolean existCategory(String name) {
		
		return addCategoryRepository.existsByCategory(name);
	}



	@Override
	public boolean deleteCategory(Integer id) {
		AddCategory category=addCategoryRepository.findById(id).orElse(null);
		if(category!=null) {
			addCategoryRepository.delete(category);
			return true;
		}
		return false;
	}



	@Override
	public AddCategory getCategoryById(Integer id) {
		AddCategory category=addCategoryRepository.findById(id).orElse(null);
		return category;
	}



	@Override
	public List<AddCategory> getAllActiveCategory() {
		List<AddCategory> categories = addCategoryRepository.findByIsActiveTrue();
		return categories;
	}
    
	

}
