package com.jsp.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.ecommerce.model.AddCategory;

public interface AddCategoryRepository extends JpaRepository<AddCategory, Integer>{
	
	public boolean existsByCategory(String name);

	public List<AddCategory> findByIsActiveTrue();

}
